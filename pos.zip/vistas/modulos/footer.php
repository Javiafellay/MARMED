<footer class="main-footer">
	
	<strong>Copyright &copy; 2020 <a href="https://www.tutorialesatualcance.com" target="_blank">Javier Martinez Guanez</a>.</strong>

	Todos los derechos reservados.


</footer>